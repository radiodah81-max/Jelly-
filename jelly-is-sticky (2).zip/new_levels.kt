,
    Level(
        name = "المرحلة 6",
        w = 6, h = 6,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0),
            intArrayOf(0,1,0,0,0,0),
            intArrayOf(0,2,0,3,0,0),
            intArrayOf(0,0,0,3,2,0),
            intArrayOf(0,0,0,0,0,0),
            intArrayOf(0,0,0,0,0,0),
        ),
        targets = listOf(Point(4, 1), Point(4, 2), Point(4, 3))
    ),
    Level(
        name = "المرحلة 7",
        w = 7, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,0,3,0,3,0,0),
            intArrayOf(0,0,3,1,3,0,0),
            intArrayOf(0,0,3,0,3,0,0),
            intArrayOf(0,2,0,0,0,2,0),
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(3, 1), Point(3, 5), Point(3, 6))
    ),
    Level(
        name = "المرحلة 8",
        w = 7, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,2,0,0,0,2,0),
            intArrayOf(0,0,3,0,3,0,0),
            intArrayOf(0,0,0,1,0,0,0),
            intArrayOf(0,0,3,0,3,0,0),
            intArrayOf(0,2,0,0,0,2,0),
            intArrayOf(0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(3, 0), Point(3, 1), Point(3, 2), Point(3, 4), Point(3, 5))
    ),
    Level(
        name = "المرحلة 9",
        w = 8, h = 8,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,1,0,0,0,0,2,0),
            intArrayOf(0,0,3,3,3,3,0,0),
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,0,3,3,3,3,0,0),
            intArrayOf(0,2,0,0,0,0,2,0),
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(3, 3), Point(4, 3), Point(3, 4), Point(4, 4))
    ),
    Level(
        name = "المرحلة 10",
        w = 6, h = 6,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0),
            intArrayOf(0,1,2,2,0,0),
            intArrayOf(0,0,0,0,0,0),
            intArrayOf(0,0,3,3,0,0),
            intArrayOf(0,0,3,3,0,0),
            intArrayOf(0,0,0,0,0,0),
        ),
        targets = listOf(Point(1, 4), Point(1, 5), Point(2, 5))
    ),
    Level(
        name = "المرحلة 11",
        w = 7, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,1,0,0,0,2,0),
            intArrayOf(0,0,3,3,3,0,0),
            intArrayOf(0,0,0,2,0,0,0),
            intArrayOf(0,0,3,3,3,0,0),
            intArrayOf(0,2,0,0,0,0,0),
            intArrayOf(0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(5, 5), Point(5, 4), Point(4, 5), Point(4, 4))
    ),
    Level(
        name = "المرحلة 12",
        w = 8, h = 8,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,1,0,0,0,0,0,0),
            intArrayOf(0,0,3,0,0,3,0,0),
            intArrayOf(0,0,0,2,2,0,0,0),
            intArrayOf(0,0,0,2,2,0,0,0),
            intArrayOf(0,0,3,0,0,3,0,0),
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(0, 7), Point(1, 7), Point(2, 7), Point(3, 7), Point(4, 7))
    ),
    Level(
        name = "المرحلة 13",
        w = 7, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,2,0,3,0,2,0),
            intArrayOf(0,0,0,3,0,0,0),
            intArrayOf(0,3,3,1,3,3,0),
            intArrayOf(0,0,0,3,0,0,0),
            intArrayOf(0,2,0,3,0,2,0),
            intArrayOf(0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(0, 0), Point(6, 0), Point(0, 6), Point(6, 6), Point(3, 3))
    ),
    Level(
        name = "المرحلة 14",
        w = 6, h = 6,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0),
            intArrayOf(0,2,0,0,2,0),
            intArrayOf(0,0,3,3,0,0),
            intArrayOf(0,0,3,3,0,0),
            intArrayOf(0,0,1,0,0,0),
            intArrayOf(0,0,0,0,0,0),
        ),
        targets = listOf(Point(2, 2), Point(2, 3), Point(3, 2))
    ),
    Level(
        name = "المرحلة 15",
        w = 8, h = 8,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,0,3,3,3,3,0,0),
            intArrayOf(0,0,2,0,0,2,0,0),
            intArrayOf(0,0,3,0,0,3,0,0),
            intArrayOf(0,0,3,1,0,3,0,0),
            intArrayOf(0,0,2,0,0,2,0,0),
            intArrayOf(0,0,3,3,3,3,0,0),
            intArrayOf(0,0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(0, 0), Point(1, 0), Point(0, 1), Point(1, 1), Point(2, 2))
    ),
    Level(
        name = "المرحلة 16",
        w = 7, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,1,0,0,0,0,0),
            intArrayOf(0,3,3,0,3,3,0),
            intArrayOf(0,0,2,0,2,0,0),
            intArrayOf(0,3,3,0,3,3,0),
            intArrayOf(0,0,2,0,2,0,0),
            intArrayOf(0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(3, 0), Point(3, 1), Point(3, 2), Point(3, 3), Point(3, 4))
    ),
    Level(
        name = "المرحلة 17",
        w = 7, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,2,2,0,2,2,0),
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,0,0,1,0,0,0),
            intArrayOf(0,0,3,3,3,0,0),
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(3, 5), Point(2, 5), Point(4, 5), Point(3, 6), Point(2, 6))
    ),
    Level(
        name = "المرحلة 18",
        w = 8, h = 8,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,0,0,2,0,0,0,0),
            intArrayOf(0,0,3,3,3,0,0,0),
            intArrayOf(0,2,3,1,3,2,0,0),
            intArrayOf(0,0,3,3,3,0,0,0),
            intArrayOf(0,0,0,2,0,0,0,0),
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(0, 0), Point(7, 0), Point(0, 7), Point(7, 7), Point(3, 3))
    ),
    Level(
        name = "المرحلة 19",
        w = 6, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0),
            intArrayOf(0,2,0,0,2,0),
            intArrayOf(0,0,3,3,0,0),
            intArrayOf(0,0,1,0,0,0),
            intArrayOf(0,0,3,3,0,0),
            intArrayOf(0,2,0,0,2,0),
            intArrayOf(0,0,0,0,0,0),
        ),
        targets = listOf(Point(2, 0), Point(3, 0), Point(2, 6), Point(3, 6), Point(0, 3))
    ),
    Level(
        name = "المرحلة 20",
        w = 8, h = 8,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,1,0,0,0,0,2,0),
            intArrayOf(0,0,3,3,3,3,0,0),
            intArrayOf(0,0,3,0,0,3,0,0),
            intArrayOf(0,2,3,0,0,3,2,0),
            intArrayOf(0,0,3,3,3,3,0,0),
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,0,0,2,0,0,0,0),
        ),
        targets = listOf(Point(3, 3), Point(4, 3), Point(3, 4), Point(4, 4), Point(3, 5))
    ),
    Level(
        name = "المرحلة 21",
        w = 7, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,1,0,0,0,0,0),
            intArrayOf(0,0,3,3,3,0,0),
            intArrayOf(0,0,0,2,0,0,0),
            intArrayOf(0,0,3,0,3,0,0),
            intArrayOf(0,2,0,2,0,2,0),
            intArrayOf(0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(0, 5), Point(1, 5), Point(2, 5), Point(3, 5), Point(4, 5))
    ),
    Level(
        name = "المرحلة 22",
        w = 8, h = 8,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,0,2,0,0,2,0,0),
            intArrayOf(0,3,3,0,0,3,3,0),
            intArrayOf(0,0,0,1,0,0,0,0),
            intArrayOf(0,3,3,0,0,3,3,0),
            intArrayOf(0,0,2,0,0,2,0,0),
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,0,2,0,0,2,0,0),
        ),
        targets = listOf(Point(2, 3), Point(3, 3), Point(4, 3), Point(5, 3), Point(3, 2), Point(4, 2))
    ),
    Level(
        name = "المرحلة 23",
        w = 7, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,0,0,2,0,0,0),
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,3,0,1,0,3,0),
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,2,0,0,0,2,0),
            intArrayOf(0,0,3,3,3,0,0),
        ),
        targets = listOf(Point(3, 0), Point(3, 1), Point(3, 5), Point(3, 6))
    ),
    Level(
        name = "المرحلة 24",
        w = 6, h = 6,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0),
            intArrayOf(0,1,2,0,2,0),
            intArrayOf(0,0,0,0,0,0),
            intArrayOf(0,0,3,3,0,0),
            intArrayOf(0,2,0,0,2,0),
            intArrayOf(0,0,0,0,0,0),
        ),
        targets = listOf(Point(2, 2), Point(3, 2), Point(2, 4), Point(3, 4), Point(2, 5))
    ),
    Level(
        name = "المرحلة 25",
        w = 7, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,2,0,3,0,2,0),
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,3,0,1,0,3,0),
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,2,0,3,0,2,0),
            intArrayOf(0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(0, 0), Point(6, 0), Point(0, 6), Point(6, 6), Point(3, 3))
    ),
    Level(
        name = "المرحلة 26",
        w = 8, h = 8,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,1,0,0,0,0,2,0),
            intArrayOf(0,0,3,3,3,3,0,0),
            intArrayOf(0,0,0,3,3,0,0,0),
            intArrayOf(0,0,0,3,3,0,0,0),
            intArrayOf(0,2,0,0,0,0,2,0),
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,0,2,0,0,2,0,0),
        ),
        targets = listOf(Point(2, 3), Point(5, 3), Point(2, 4), Point(5, 4), Point(3, 6), Point(4, 6))
    ),
    Level(
        name = "المرحلة 27",
        w = 7, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,0,2,2,2,0,0),
            intArrayOf(0,0,0,3,0,0,0),
            intArrayOf(0,0,0,1,0,0,0),
            intArrayOf(0,0,0,3,0,0,0),
            intArrayOf(0,0,2,2,2,0,0),
            intArrayOf(0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(0, 3), Point(1, 3), Point(2, 3), Point(4, 3), Point(5, 3), Point(6, 3), Point(3, 0))
    ),
    Level(
        name = "المرحلة 28",
        w = 7, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,2,0,0,0,2,0),
            intArrayOf(0,0,3,1,3,0,0),
            intArrayOf(0,0,3,0,3,0,0),
            intArrayOf(0,0,3,2,3,0,0),
            intArrayOf(0,2,0,0,0,2,0),
            intArrayOf(0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(3, 1), Point(3, 2), Point(3, 3), Point(3, 5), Point(3, 6), Point(0, 3))
    ),
    Level(
        name = "المرحلة 29",
        w = 8, h = 8,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,2,0,2,0,2,0,0),
            intArrayOf(0,0,3,0,0,3,0,0),
            intArrayOf(0,0,0,1,0,0,0,0),
            intArrayOf(0,0,3,0,0,3,0,0),
            intArrayOf(0,2,0,2,0,2,0,0),
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(3, 0), Point(4, 0), Point(3, 1), Point(4, 1), Point(3, 6), Point(4, 6), Point(3, 7))
    ),
    Level(
        name = "المرحلة 30",
        w = 7, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,1,0,2,0,2,0),
            intArrayOf(0,0,0,3,0,0,0),
            intArrayOf(0,2,3,3,3,2,0),
            intArrayOf(0,0,0,3,0,0,0),
            intArrayOf(0,2,0,2,0,2,0),
            intArrayOf(0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(0, 0), Point(1, 0), Point(2, 0), Point(3, 0), Point(4, 0), Point(5, 0), Point(6, 0), Point(0, 1))
    )