import re

with open('app/src/main/java/com/example/MainActivity.kt', 'r') as f:
    content = f.read()

levels_str = content.split("val LEVELS = listOf(")[1].split("class SoundManager")[0]

blocks = levels_str.split('Level(')[1:]
for idx, block in enumerate(blocks):
    w_match = re.search(r'w\s*=\s*(\d+)', block)
    h_match = re.search(r'h\s*=\s*(\d+)', block)
    if not w_match or not h_match: continue
    w, h = int(w_match.group(1)), int(h_match.group(1))
    
    rows = []
    for line in block.split('\n'):
        if 'intArrayOf(' in line:
            r = line.split('intArrayOf(')[1].split(')')[0]
            rows.append(r)
            
    if len(rows) != h:
        print(f"Level {idx+1} has incorrect h: expected {h}, got {len(rows)}")
    for r_idx, row in enumerate(rows):
        cols = row.split(',')
        if len(cols) != w:
            print(f"Level {idx+1} row {r_idx} has incorrect w: expected {w}, got {len(cols)}")
            
    targets_str = re.search(r'targets\s*=\s*listOf\((.*?)\)', block)
    if not targets_str: continue
    targets_str = targets_str.group(1)
    
    targets = re.findall(r'Point\((\d+),\s*(\d+)\)', targets_str)
    
    for tx_str, ty_str in targets:
        tx, ty = int(tx_str), int(ty_str)
        if tx < 0 or tx >= w or ty < 0 or ty >= h:
            print(f"Level {idx+1} has out-of-bounds target: ({tx}, {ty})")
        else:
            val = rows[ty].split(',')[tx].strip()
            if val == '3':
                print(f"Level {idx+1} has target on a wall: ({tx}, {ty})")
