package com.example

import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.annotation.Config
import android.app.Application
import androidx.test.core.app.ApplicationProvider

@RunWith(AndroidJUnit4::class)
@Config(manifest=Config.NONE)
class TargetsTest {
    @Test
    fun testAllTargets() {
        var hasErrors = false
        for (i in LEVELS.indices) {
            val level = LEVELS[i]
            for (t in level.targets) {
                if (t.x < 0 || t.x >= level.w || t.y < 0 || t.y >= level.h) {
                    println("Level ${i+1} has out of bounds target: ${t} for w=${level.w}, h=${level.h}")
                    hasErrors = true
                }
                else if (level.grid[t.y][t.x] == 3) {
                    println("Level ${i+1} has target on a wall: ${t}")
                    hasErrors = true
                }
            }
        }
        if (hasErrors) throw AssertionError("Errors found!")
    }
}
