package com.example

import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.annotation.Config

@RunWith(AndroidJUnit4::class)
@Config(manifest=Config.NONE)
class GridDimensionsTest {
    @Test
    fun testGridDimensions() {
        for (i in LEVELS.indices) {
            val level = LEVELS[i]
            if (level.grid.size != level.h) {
                throw AssertionError("Level ${i+1} has incorrect h. Expected ${level.h}, got ${level.grid.size}")
            }
            for (row in level.grid) {
                if (row.size != level.w) {
                    throw AssertionError("Level ${i+1} has incorrect row size. Expected ${level.w}, got ${row.size}")
                }
            }
        }
    }
}
