package com.example

import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.annotation.Config
import android.app.Application
import androidx.test.core.app.ApplicationProvider

@RunWith(AndroidJUnit4::class)
@Config(manifest=Config.NONE)
class Level6Test {
    @Test
    fun testLevel6() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val viewModel = GameViewModel(app)
        
        viewModel.startLevel(5)
        
        // This will throw if it crashes during move
        viewModel.move(1, 0)
        
        assert(false) { "Reached end of test!" }
    }
}
