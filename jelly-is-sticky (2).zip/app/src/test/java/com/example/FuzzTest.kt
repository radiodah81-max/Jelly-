package com.example

import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.annotation.Config
import android.app.Application
import androidx.test.core.app.ApplicationProvider
import java.util.Random

@RunWith(AndroidJUnit4::class)
@Config(manifest=Config.NONE)
class FuzzTest {
    @Test
    fun testAllLevels() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val viewModel = GameViewModel(app)
        val rand = Random(42)
        
        for (i in LEVELS.indices) {
            println("Testing level ${i+1}")
            viewModel.startLevel(i)
            
            // simulate 50 random moves
            for (m in 0..50) {
                val dir = rand.nextInt(4)
                when(dir) {
                    0 -> viewModel.move(1, 0)
                    1 -> viewModel.move(-1, 0)
                    2 -> viewModel.move(0, 1)
                    3 -> viewModel.move(0, -1)
                }
                
                // If the game is won, exit this level early
                if (viewModel.isWon) break
            }
        }
    }
}
