package com.example

import android.app.Application
import android.content.Context
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import androidx.lifecycle.AndroidViewModel
import android.os.Bundle
import kotlinx.coroutines.*
import kotlin.math.sin
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.min

// --- Data Models ---
data class Point(val x: Int, val y: Int)

data class Level(
    val name: String,
    val w: Int,
    val h: Int,
    val grid: Array<IntArray>,
    val targets: List<Point>,
    val threeStarMoves: Int = 10,
    val twoStarMoves: Int = 15
)

val LEVELS = listOf(
    Level(
        name = "المرحلة 1",
        w = 6, h = 6,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0),
            intArrayOf(0,1,0,0,0,0),
            intArrayOf(0,0,0,0,0,0),
            intArrayOf(0,2,0,0,0,0),
            intArrayOf(0,0,0,0,0,0),
            intArrayOf(0,0,0,0,0,0),
        ),
        targets = listOf(Point(4, 2), Point(4, 3))
    ),
    Level(
        name = "المرحلة 2",
        w = 7, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,1,0,0,0,0,0),
            intArrayOf(0,2,2,0,0,0,0),
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,0,3,0,0,0,0),
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(5, 2), Point(5, 3), Point(5, 4))
    ),
    Level(
        name = "المرحلة 3",
        w = 7, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,1,0,0,0,2,0),
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,2,0,0,0,0,0),
            intArrayOf(0,0,0,0,0,2,0),
            intArrayOf(0,0,3,3,0,0,0),
            intArrayOf(0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(3, 2), Point(3, 3), Point(4, 2), Point(4, 3))
    ),
    Level(
        name = "المرحلة 4",
        w = 7, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,1,0,0,0,0,0),
            intArrayOf(0,2,0,0,0,0,0),
            intArrayOf(0,2,2,0,0,0,0),
            intArrayOf(0,2,0,0,0,0,0),
            intArrayOf(0,0,3,0,0,0,0),
            intArrayOf(0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(5, 1), Point(5, 2), Point(5, 3), Point(5, 4), Point(5, 5))
    ),
    Level(
        name = "المرحلة 5",
        w = 6, h = 6,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0),
            intArrayOf(0,1,0,0,2,0),
            intArrayOf(0,0,0,0,0,0),
            intArrayOf(0,0,3,3,0,0),
            intArrayOf(0,0,0,0,2,0),
            intArrayOf(0,0,0,0,0,0),
        ),
        targets = listOf(Point(2, 4), Point(3, 4), Point(4, 4))
    ),
    Level(
        name = "المرحلة 6",
        w = 6, h = 6,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0),
            intArrayOf(0,1,0,0,0,0),
            intArrayOf(0,2,0,3,0,0),
            intArrayOf(0,0,0,3,2,0),
            intArrayOf(0,0,0,0,0,0),
            intArrayOf(0,0,0,0,0,0),
        ),
        targets = listOf(Point(4, 1), Point(4, 2), Point(4, 3))
    ),
    Level(
        name = "المرحلة 7",
        w = 7, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,0,3,0,3,0,0),
            intArrayOf(0,0,3,1,3,0,0),
            intArrayOf(0,0,3,0,3,0,0),
            intArrayOf(0,2,0,0,0,2,0),
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(3, 1), Point(3, 5), Point(3, 6))
    ),
    Level(
        name = "المرحلة 8",
        w = 7, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,2,0,0,0,2,0),
            intArrayOf(0,0,3,0,3,0,0),
            intArrayOf(0,0,0,1,0,0,0),
            intArrayOf(0,0,3,0,3,0,0),
            intArrayOf(0,2,0,0,0,2,0),
            intArrayOf(0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(3, 0), Point(3, 1), Point(3, 2), Point(3, 4), Point(3, 5))
    ),
    Level(
        name = "المرحلة 9",
        w = 8, h = 8,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,1,0,0,0,0,2,0),
            intArrayOf(0,0,3,3,3,3,0,0),
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,0,3,3,3,3,0,0),
            intArrayOf(0,2,0,0,0,0,2,0),
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(2, 3), Point(3, 3), Point(4, 3), Point(5, 3))
    ),
    Level(
        name = "المرحلة 10",
        w = 6, h = 6,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0),
            intArrayOf(0,1,2,2,0,0),
            intArrayOf(0,0,0,0,0,0),
            intArrayOf(0,0,3,3,0,0),
            intArrayOf(0,0,3,3,0,0),
            intArrayOf(0,0,0,0,0,0),
        ),
        targets = listOf(Point(1, 4), Point(1, 5), Point(2, 5))
    ),
    Level(
        name = "المرحلة 11",
        w = 7, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,1,0,0,0,2,0),
            intArrayOf(0,0,3,3,3,0,0),
            intArrayOf(0,0,0,2,0,0,0),
            intArrayOf(0,0,3,3,3,0,0),
            intArrayOf(0,2,0,0,0,0,0),
            intArrayOf(0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(5, 5), Point(5, 4), Point(4, 5), Point(3, 5))
    ),
    Level(
        name = "المرحلة 12",
        w = 8, h = 8,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,1,0,0,0,0,0,0),
            intArrayOf(0,0,3,0,0,3,0,0),
            intArrayOf(0,0,0,2,2,0,0,0),
            intArrayOf(0,0,0,2,2,0,0,0),
            intArrayOf(0,0,3,0,0,3,0,0),
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(0, 7), Point(1, 7), Point(2, 7), Point(3, 7), Point(4, 7))
    ),
    Level(
        name = "المرحلة 13",
        w = 7, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,2,0,3,0,2,0),
            intArrayOf(0,0,0,3,0,0,0),
            intArrayOf(0,3,3,1,3,3,0),
            intArrayOf(0,0,0,3,0,0,0),
            intArrayOf(0,2,0,3,0,2,0),
            intArrayOf(0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(0, 0), Point(6, 0), Point(0, 6), Point(6, 6), Point(3, 3))
    ),
    Level(
        name = "المرحلة 14",
        w = 6, h = 6,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0),
            intArrayOf(0,2,0,0,2,0),
            intArrayOf(0,0,3,3,0,0),
            intArrayOf(0,0,3,3,0,0),
            intArrayOf(0,0,1,0,0,0),
            intArrayOf(0,0,0,0,0,0),
        ),
        targets = listOf(Point(2, 1), Point(3, 1), Point(2, 4))
    ),
    Level(
        name = "المرحلة 15",
        w = 8, h = 8,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,0,3,3,3,3,0,0),
            intArrayOf(0,0,2,0,0,2,0,0),
            intArrayOf(0,0,3,0,0,3,0,0),
            intArrayOf(0,0,3,1,0,3,0,0),
            intArrayOf(0,0,2,0,0,2,0,0),
            intArrayOf(0,0,3,3,3,3,0,0),
            intArrayOf(0,0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(0, 0), Point(1, 0), Point(0, 1), Point(1, 1), Point(2, 2))
    ),
    Level(
        name = "المرحلة 16",
        w = 7, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,1,0,0,0,0,0),
            intArrayOf(0,3,3,0,3,3,0),
            intArrayOf(0,0,2,0,2,0,0),
            intArrayOf(0,3,3,0,3,3,0),
            intArrayOf(0,0,2,0,2,0,0),
            intArrayOf(0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(3, 0), Point(3, 1), Point(3, 2), Point(3, 3), Point(3, 4))
    ),
    Level(
        name = "المرحلة 17",
        w = 7, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,2,2,0,2,2,0),
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,0,0,1,0,0,0),
            intArrayOf(0,0,3,3,3,0,0),
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(3, 5), Point(2, 5), Point(4, 5), Point(3, 6), Point(2, 6))
    ),
    Level(
        name = "المرحلة 18",
        w = 8, h = 8,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,0,0,2,0,0,0,0),
            intArrayOf(0,0,3,3,3,0,0,0),
            intArrayOf(0,2,3,1,3,2,0,0),
            intArrayOf(0,0,3,3,3,0,0,0),
            intArrayOf(0,0,0,2,0,0,0,0),
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(0, 0), Point(7, 0), Point(0, 7), Point(7, 7), Point(3, 3))
    ),
    Level(
        name = "المرحلة 19",
        w = 6, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0),
            intArrayOf(0,2,0,0,2,0),
            intArrayOf(0,0,3,3,0,0),
            intArrayOf(0,0,1,0,0,0),
            intArrayOf(0,0,3,3,0,0),
            intArrayOf(0,2,0,0,2,0),
            intArrayOf(0,0,0,0,0,0),
        ),
        targets = listOf(Point(2, 0), Point(3, 0), Point(2, 6), Point(3, 6), Point(0, 3))
    ),
    Level(
        name = "المرحلة 20",
        w = 8, h = 8,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,1,0,0,0,0,2,0),
            intArrayOf(0,0,3,3,3,3,0,0),
            intArrayOf(0,0,3,0,0,3,0,0),
            intArrayOf(0,2,3,0,0,3,2,0),
            intArrayOf(0,0,3,3,3,3,0,0),
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,0,0,2,0,0,0,0),
        ),
        targets = listOf(Point(3, 3), Point(4, 3), Point(3, 4), Point(4, 4), Point(4, 6))
    ),
    Level(
        name = "المرحلة 21",
        w = 7, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,1,0,0,0,0,0),
            intArrayOf(0,0,3,3,3,0,0),
            intArrayOf(0,0,0,2,0,0,0),
            intArrayOf(0,0,3,0,3,0,0),
            intArrayOf(0,2,0,2,0,2,0),
            intArrayOf(0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(0, 5), Point(1, 5), Point(2, 5), Point(3, 5), Point(4, 5))
    ),
    Level(
        name = "المرحلة 22",
        w = 8, h = 8,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,0,2,0,0,2,0,0),
            intArrayOf(0,3,3,0,0,3,3,0),
            intArrayOf(0,0,0,1,0,0,0,0),
            intArrayOf(0,3,3,0,0,3,3,0),
            intArrayOf(0,0,2,0,0,2,0,0),
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,0,2,0,0,2,0,0),
        ),
        targets = listOf(Point(2, 3), Point(3, 3), Point(4, 3), Point(5, 3), Point(3, 2), Point(4, 2))
    ),
    Level(
        name = "المرحلة 23",
        w = 7, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,0,0,2,0,0,0),
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,3,0,1,0,3,0),
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,2,0,0,0,2,0),
            intArrayOf(0,0,3,3,3,0,0),
        ),
        targets = listOf(Point(3, 0), Point(3, 1), Point(3, 5), Point(3, 4))
    ),
    Level(
        name = "المرحلة 24",
        w = 6, h = 6,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0),
            intArrayOf(0,1,2,0,2,0),
            intArrayOf(0,0,0,0,0,0),
            intArrayOf(0,0,3,3,0,0),
            intArrayOf(0,2,0,0,2,0),
            intArrayOf(0,0,0,0,0,0),
        ),
        targets = listOf(Point(2, 2), Point(3, 2), Point(2, 4), Point(3, 4), Point(2, 5))
    ),
    Level(
        name = "المرحلة 25",
        w = 7, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,2,0,3,0,2,0),
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,3,0,1,0,3,0),
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,2,0,3,0,2,0),
            intArrayOf(0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(0, 0), Point(6, 0), Point(0, 6), Point(6, 6), Point(3, 3))
    ),
    Level(
        name = "المرحلة 26",
        w = 8, h = 8,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,1,0,0,0,0,2,0),
            intArrayOf(0,0,3,3,3,3,0,0),
            intArrayOf(0,0,0,3,3,0,0,0),
            intArrayOf(0,0,0,3,3,0,0,0),
            intArrayOf(0,2,0,0,0,0,2,0),
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,0,2,0,0,2,0,0),
        ),
        targets = listOf(Point(2, 3), Point(5, 3), Point(2, 4), Point(5, 4), Point(3, 6), Point(4, 6))
    ),
    Level(
        name = "المرحلة 27",
        w = 7, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,0,2,2,2,0,0),
            intArrayOf(0,0,0,3,0,0,0),
            intArrayOf(0,0,0,1,0,0,0),
            intArrayOf(0,0,0,3,0,0,0),
            intArrayOf(0,0,2,2,2,0,0),
            intArrayOf(0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(0, 3), Point(1, 3), Point(2, 3), Point(4, 3), Point(5, 3), Point(6, 3), Point(3, 0))
    ),
    Level(
        name = "المرحلة 28",
        w = 7, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,2,0,0,0,2,0),
            intArrayOf(0,0,3,1,3,0,0),
            intArrayOf(0,0,3,0,3,0,0),
            intArrayOf(0,0,3,2,3,0,0),
            intArrayOf(0,2,0,0,0,2,0),
            intArrayOf(0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(3, 1), Point(3, 2), Point(3, 3), Point(3, 5), Point(3, 6), Point(0, 3))
    ),
    Level(
        name = "المرحلة 29",
        w = 8, h = 8,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,2,0,2,0,2,0,0),
            intArrayOf(0,0,3,0,0,3,0,0),
            intArrayOf(0,0,0,1,0,0,0,0),
            intArrayOf(0,0,3,0,0,3,0,0),
            intArrayOf(0,2,0,2,0,2,0,0),
            intArrayOf(0,0,0,0,0,0,0,0),
            intArrayOf(0,0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(3, 0), Point(4, 0), Point(3, 1), Point(4, 1), Point(3, 6), Point(4, 6), Point(3, 7))
    ),
    Level(
        name = "المرحلة 30",
        w = 7, h = 7,
        grid = arrayOf(
            intArrayOf(0,0,0,0,0,0,0),
            intArrayOf(0,1,0,2,0,2,0),
            intArrayOf(0,0,0,3,0,0,0),
            intArrayOf(0,2,3,3,3,2,0),
            intArrayOf(0,0,0,3,0,0,0),
            intArrayOf(0,2,0,2,0,2,0),
            intArrayOf(0,0,0,0,0,0,0),
        ),
        targets = listOf(Point(0, 0), Point(1, 0), Point(2, 0), Point(3, 0), Point(4, 0), Point(5, 0), Point(6, 0), Point(0, 1))
    )
)

class SoundManager {
    private val sampleRate = 44100
    private val scope = CoroutineScope(Dispatchers.IO)

    private fun playTone(durationMs: Int, type: String, freqStart: Double, freqEnd: Double = freqStart) {
        scope.launch {
            var audioTrack: android.media.AudioTrack? = null
            try {
                val numSamples = (durationMs * sampleRate) / 1000
                val generatedSnd = ByteArray(2 * numSamples)
                var angle = 0.0

                for (i in 0 until numSamples) {
                    val progress = i.toDouble() / numSamples
                    val currentFreq = freqStart + (freqEnd - freqStart) * progress
                    angle += 2.0 * Math.PI * currentFreq / sampleRate

                    val sampleVal: Double = when (type) {
                        "sine" -> sin(angle)
                        "square" -> if (sin(angle) > 0) 1.0 else -1.0
                        "triangle" -> 2.0 / Math.PI * kotlin.math.asin(sin(angle))
                        else -> sin(angle)
                    }

                    // Apply envelope to avoid clicks
                    val envelope = if (i < 441) i / 441.0 else if (i > numSamples - 441) (numSamples - i) / 441.0 else 1.0
                    val sample = (sampleVal * 32767 * 0.3 * envelope).toInt().toShort()

                    generatedSnd[2 * i] = (sample.toInt() and 0x00FF).toByte()
                    generatedSnd[2 * i + 1] = ((sample.toInt() and 0xFF00) ushr 8).toByte()
                }

                audioTrack = android.media.AudioTrack.Builder()
                    .setAudioAttributes(
                        android.media.AudioAttributes.Builder()
                            .setUsage(android.media.AudioAttributes.USAGE_GAME)
                            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        android.media.AudioFormat.Builder()
                            .setEncoding(android.media.AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(android.media.AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(generatedSnd.size)
                    .setTransferMode(android.media.AudioTrack.MODE_STATIC)
                    .build()
                audioTrack.write(generatedSnd, 0, generatedSnd.size)
                audioTrack.play()
                kotlinx.coroutines.delay(durationMs.toLong() + 50)
            } catch (e: Exception) {
                // Ignore audio errors
            } finally {
                audioTrack?.release()
            }
        }
    }

    fun pop() = playTone(100, "sine", 600.0, 300.0)
    fun thud() = playTone(150, "triangle", 150.0, 150.0)
    fun crunch() = playTone(200, "square", 200.0, 100.0)
    fun slide() = playTone(100, "sine", 400.0, 500.0)
    
    fun win() {
        scope.launch {
            playTone(150, "sine", 523.0)
            delay(150)
            playTone(150, "sine", 659.0)
            delay(150)
            playTone(150, "sine", 784.0)
            delay(150)
            playTone(300, "sine", 1047.0)
        }
    }
}

// --- ViewModel ---
class GameViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = application.getSharedPreferences("JellyGamePrefs", Context.MODE_PRIVATE)
    val soundManager = SoundManager()
    
    var unlockedLevel by mutableStateOf(prefs.getInt("unlockedLevel", 0))
        private set

    var extraLevels by mutableStateOf(prefs.getInt("extraLevels", 0))
        private set

    fun incrementExtraLevels() {
        extraLevels++
        prefs.edit().putInt("extraLevels", extraLevels).apply()
    }

    private fun updateUnlockedLevel(level: Int) {
        if (level > unlockedLevel) {
            unlockedLevel = level
            prefs.edit().putInt("unlockedLevel", level).apply()
        }
    }

    fun getLevelStars(levelIdx: Int): Int {
        return prefs.getInt("stars_$levelIdx", 0)
    }

    private fun updateLevelStars(levelIdx: Int, stars: Int) {
        val currentStars = getLevelStars(levelIdx)
        if (stars > currentStars) {
            prefs.edit().putInt("stars_$levelIdx", stars).apply()
        }
    }

    var currentLevelIdx by mutableStateOf(0)

    var grid by mutableStateOf(emptyArray<IntArray>())
    var moves by mutableStateOf(0)
    var isWon by mutableStateOf(false)
    var isLost by mutableStateOf(false)

    private val history = mutableListOf<Pair<Array<IntArray>, Int>>()

    fun startLevel(idx: Int) {
        if (idx >= LEVELS.size) return
        currentLevelIdx = idx
        val level = LEVELS[idx]
        grid = level.grid.map { it.clone() }.toTypedArray()
        moves = 0
        isWon = false
        isLost = false
        history.clear()
    }

    fun findBlob(g: Array<IntArray>): List<Point> {
        val h = g.size
        if (h == 0) return emptyList()
        val w = g[0].size
        var start: Point? = null
        for (y in 0 until h) {
            for (x in 0 until w) {
                if (g[y][x] == 1) {
                    start = Point(x, y)
                    break
                }
            }
            if (start != null) break
        }
        if (start == null) return emptyList()

        val blob = mutableListOf<Point>()
        val visited = mutableSetOf<Point>()
        val q = mutableListOf<Point>()
        q.add(start)
        visited.add(start)

        val dirs = listOf(Point(0, 1), Point(0, -1), Point(1, 0), Point(-1, 0))

        while (q.isNotEmpty()) {
            val cur = q.removeAt(0)
            blob.add(cur)
            for (dir in dirs) {
                val nx = cur.x + dir.x
                val ny = cur.y + dir.y
                val np = Point(nx, ny)
                if (nx in 0 until w && ny in 0 until h && !visited.contains(np)) {
                    if (g[ny][nx] == 1 || g[ny][nx] == 2) {
                        visited.add(np)
                        q.add(np)
                    }
                }
            }
        }
        return blob
    }

    fun move(dx: Int, dy: Int) {
        if (isWon || isLost) return
        if (grid.isEmpty()) return
        if (currentLevelIdx >= LEVELS.size) return
        val h = grid.size
        val w = grid[0].size
        val blob = findBlob(grid)
        if (blob.isEmpty()) return

        val mainJelly = blob.find { grid[it.y][it.x] == 1 } ?: return

        val moving = blob.toMutableSet()
        val blocked = mutableSetOf<Point>()

        var changed = true
        while (changed) {
            changed = false
            val toBlock = mutableSetOf<Point>()

            for (p in moving) {
                val nx = p.x + dx
                val ny = p.y + dy

                if (nx !in 0 until w || ny !in 0 until h) {
                    toBlock.add(p)
                    continue
                }
                if (grid[ny][nx] == 3) {
                    toBlock.add(p)
                    continue
                }
                val targetCell = grid[ny][nx]
                if (targetCell == 1 || targetCell == 2) {
                    val targetPoint = Point(nx, ny)
                    if (targetPoint !in moving) {
                        toBlock.add(p)
                        continue
                    }
                }
            }

            if (mainJelly in moving && mainJelly !in toBlock) {
                val connected = mutableSetOf<Point>()
                val q = mutableListOf(mainJelly)
                connected.add(mainJelly)
                val dirs = listOf(Point(0, 1), Point(0, -1), Point(1, 0), Point(-1, 0))
                while (q.isNotEmpty()) {
                    val cur = q.removeAt(0)
                    for (dir in dirs) {
                        val nx = cur.x + dir.x
                        val ny = cur.y + dir.y
                        val np = Point(nx, ny)
                        if (np in moving && np !in toBlock && np !in connected) {
                            connected.add(np)
                            q.add(np)
                        }
                    }
                }
                for (p in moving) {
                    if (p !in connected) {
                        toBlock.add(p)
                    }
                }
            } else if (mainJelly in toBlock || mainJelly !in moving) {
                toBlock.addAll(moving)
            }

            if (toBlock.isNotEmpty()) {
                moving.removeAll(toBlock)
                blocked.addAll(toBlock)
                changed = true
            }
        }

        if (mainJelly in blocked || moving.isEmpty()) {
            soundManager.thud()
            return
        }

        val historyGrid = grid.map { it.clone() }.toTypedArray()
        val newGrid = grid.map { it.clone() }.toTypedArray()

        for (cell in moving) {
            newGrid[cell.y][cell.x] = 0
        }

        for (cell in moving) {
            newGrid[cell.y + dy][cell.x + dx] = grid[cell.y][cell.x]
        }

        // Check for pop (new jelly connected)
        val oldBlob = findBlob(grid)
        val oldBlobSize = oldBlob.size
        val newBlob = findBlob(newGrid).toSet()
        val newBlobSize = newBlob.size
        val pop = newBlobSize > oldBlobSize

        // Check for crunch (strawberry covered)
        val level = LEVELS[currentLevelIdx]
        var oldCovered = 0
        var newCovered = 0
        for (t in level.targets) {
            val wasCovered = grid[t.y][t.x] == 1 || grid[t.y][t.x] == 2
            val isCovered = newGrid[t.y][t.x] == 1 || newGrid[t.y][t.x] == 2
            if (wasCovered) oldCovered++
            if (isCovered) {
                newCovered++
            }
        }
        val crunch = newCovered > oldCovered

        if (crunch) {
            soundManager.crunch()
        } else if (pop) {
            soundManager.pop()
        } else {
            soundManager.slide()
        }

        history.add(historyGrid to moves)
        grid = newGrid
        moves++
        checkWin()
    }

    private fun checkWin() {
        if (currentLevelIdx >= LEVELS.size) return
        val level = LEVELS[currentLevelIdx]
        var allCovered = true
        for (t in level.targets) {
            val cell = grid[t.y][t.x]
            if (cell != 1 && cell != 2) {
                allCovered = false
                break
            }
        }
        if (allCovered) {
            soundManager.win()
            isWon = true
            updateUnlockedLevel(currentLevelIdx + 1)
            var stars = 1
            if (moves <= level.threeStarMoves) stars = 3
            else if (moves <= level.twoStarMoves) stars = 2
            updateLevelStars(currentLevelIdx, stars)
        }
    }

    fun undo() {
        if (history.isEmpty() || isWon || isLost) return
        val last = history.removeLast()
        grid = last.first
        moves = last.second
    }
}

// --- Screens ---
enum class Screen { START, LEVELS, GAME }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val viewModel: GameViewModel = viewModel()
                    var currentScreen by remember { mutableStateOf(Screen.START) }

                    when (currentScreen) {
                        Screen.START -> StartScreen { currentScreen = Screen.LEVELS }
                        Screen.LEVELS -> LevelSelectScreen(
                            viewModel = viewModel,
                            onLevelSelect = {
                                viewModel.startLevel(it)
                                currentScreen = Screen.GAME
                            },
                            onBack = { currentScreen = Screen.START }
                        )
                        Screen.GAME -> GameScreen(
                            viewModel = viewModel,
                            onBack = { currentScreen = Screen.LEVELS }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StartScreen(onStart: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1A1A2E))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Column(
            modifier = Modifier
                .shadow(32.dp, RoundedCornerShape(32.dp))
                .background(Color(0xFF16213E), RoundedCornerShape(32.dp))
                .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(32.dp))
                .padding(horizontal = 24.dp, vertical = 48.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("🍮", fontSize = 80.sp)
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                "Jelly Is Sticky",
                fontSize = 32.sp,
                color = Color(0xFFFF8A80),
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "اسحب بالاتجاهات لتحرك كتلة الجيلي\nالتصق بالمكعبات الأخرى لتكبير الكتلة\nغطّي كل الفراولة \uD83C\uDF53!",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 16.sp,
                textAlign = TextAlign.Center,
                lineHeight = 26.sp
            )
            Spacer(modifier = Modifier.height(48.dp))
            Button(
                onClick = onStart,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF8A80)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
            ) {
                Text("ابدأ اللعب", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun LevelSelectScreen(viewModel: GameViewModel, onLevelSelect: (Int) -> Unit, onBack: () -> Unit) {
    val unlockedLevel = viewModel.unlockedLevel
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1A1A2E))
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("اختر المرحلة", fontSize = 28.sp, color = Color.White, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(40.dp))
        Column(
            modifier = Modifier
                .shadow(32.dp, RoundedCornerShape(32.dp))
                .background(Color(0xFF16213E), RoundedCornerShape(32.dp))
                .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(32.dp))
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            for (i in LEVELS.indices) {
                val isLocked = i > unlockedLevel
                val stars = if (isLocked) 0 else viewModel.getLevelStars(i)
                Button(
                    onClick = { if (!isLocked) onLevelSelect(i) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isLocked) Color.White.copy(alpha = 0.05f) else Color(0xFF1A1A2E)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .padding(vertical = 8.dp)
                        .fillMaxWidth()
                        .height(80.dp) // increased height to accommodate stars
                        .border(
                            1.dp,
                            if (isLocked) Color.Transparent else Color(0xFFFF8A80).copy(alpha = 0.5f),
                            RoundedCornerShape(16.dp)
                        )
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            "المرحلة ${i + 1}",
                            color = if (isLocked) Color.White.copy(alpha = 0.3f) else Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        if (!isLocked && stars > 0) {
                            Text(
                                "★".repeat(stars) + "☆".repeat(3 - stars),
                                color = Color(0xFFFFD700),
                                fontSize = 16.sp
                            )
                        }
                    }
                }
            }
            
            for (i in 0 until viewModel.extraLevels) {
                Button(
                    onClick = { },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White.copy(alpha = 0.05f)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .padding(vertical = 8.dp)
                        .fillMaxWidth()
                        .height(80.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            "المرحلة ${LEVELS.size + i + 1}",
                            color = Color.White.copy(alpha = 0.3f),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
            
            Button(
                onClick = { viewModel.incrementExtraLevels() },
                colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.1f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .padding(vertical = 8.dp)
                    .fillMaxWidth()
                    .height(64.dp)
            ) {
                Text("+", fontSize = 28.sp, color = Color.White, fontWeight = FontWeight.Bold)
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            Button(
                onClick = onBack,
                colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.1f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
            ) {
                Text("رجوع", color = Color.White, fontSize = 18.sp)
            }
        }
    }
}

@Composable
fun GameScreen(viewModel: GameViewModel, onBack: () -> Unit) {
    if (viewModel.currentLevelIdx >= LEVELS.size) return
    val level = LEVELS[viewModel.currentLevelIdx]

    var showWinOverlay by remember { mutableStateOf(false) }
    LaunchedEffect(viewModel.isWon) {
        if (viewModel.isWon) {
            delay(2000)
            showWinOverlay = true
        } else {
            showWinOverlay = false
        }
    }

    var showHint by remember { mutableStateOf(true) }
    LaunchedEffect(viewModel.currentLevelIdx) {
        showHint = true
        delay(3000)
        showHint = false
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1A1A2E))
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // App Bar (HUD)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF16213E).copy(alpha = 0.5f))
                    .border(width = 1.dp, color = Color.White.copy(alpha = 0.05f))
                    .padding(horizontal = 24.dp, vertical = 24.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Level ${String.format("%02d", viewModel.currentLevelIdx + 1)}",
                        color = Color(0xFFFF8A80),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = level.name,
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier
                            .background(Color(0xFF1A1A2E), shape = RoundedCornerShape(12.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                            .padding(horizontal = 16.dp, vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("MOVES", fontSize = 10.sp, color = Color.White.copy(alpha = 0.5f))
                        Text(
                            String.format("%02d", viewModel.moves),
                            fontSize = 14.sp,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(Color.White.copy(alpha = 0.05f), shape = RoundedCornerShape(50))
                            .clickable { viewModel.undo() },
                        contentAlignment = Alignment.Center
                    ) {
                        Text("↩", color = Color.White, fontSize = 20.sp)
                    }
                }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                GameBoard(viewModel)
            }

            // Bottom Controls
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(24.dp, RoundedCornerShape(topStart = 40.dp, topEnd = 40.dp))
                    .background(Color(0xFF16213E).copy(alpha = 0.8f), shape = RoundedCornerShape(topStart = 40.dp, topEnd = 40.dp))
                    .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(topStart = 40.dp, topEnd = 40.dp))
                    .padding(32.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onBack() }) {
                    Box(
                        modifier = Modifier
                            .padding(bottom = 4.dp)
                            .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp))
                            .padding(12.dp)
                    ) {
                        Text("☰", color = Color.White.copy(alpha = 0.7f), fontSize = 24.sp)
                    }
                    Text("LEVELS", fontSize = 10.sp, color = Color.White.copy(alpha = 0.5f), fontWeight = FontWeight.Bold)
                }

                Box(
                    modifier = Modifier
                        .offset(y = (-40).dp)
                        .size(80.dp)
                        .background(Color(0xFF1A1A2E), shape = RoundedCornerShape(50))
                        .padding(4.dp)
                        .background(
                            Brush.verticalGradient(listOf(Color(0xFFFF8A80), Color(0xFFE57373))),
                            shape = RoundedCornerShape(50)
                        )
                        .clickable { viewModel.startLevel(viewModel.currentLevelIdx) },
                    contentAlignment = Alignment.Center
                ) {
                    Text("↻", color = Color.White, fontSize = 32.sp)
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { viewModel.startLevel(viewModel.currentLevelIdx) }) {
                    Box(
                        modifier = Modifier
                            .padding(bottom = 4.dp)
                            .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp))
                            .padding(12.dp)
                    ) {
                        Text("✕", color = Color.White.copy(alpha = 0.7f), fontSize = 24.sp)
                    }
                    Text("RESET", fontSize = 10.sp, color = Color.White.copy(alpha = 0.5f), fontWeight = FontWeight.Bold)
                }
            }
        }

        if (showHint) {
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 120.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "👆",
                    fontSize = 24.sp,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
                Text(
                    "SWIPE TO MOVE",
                    color = Color.White.copy(alpha = 0.5f),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 2.sp
                )
            }
        }

        if (showWinOverlay) {
            val stars = viewModel.getLevelStars(viewModel.currentLevelIdx)
            WinOverlay(
                levelName = level.name,
                moves = viewModel.moves,
                stars = stars,
                onNext = {
                    if (viewModel.currentLevelIdx < LEVELS.size - 1) {
                        viewModel.startLevel(viewModel.currentLevelIdx + 1)
                    } else {
                        onBack()
                    }
                },
                onMenu = onBack
            )
        }
    }
}

@Composable
fun GameBoard(viewModel: GameViewModel) {
    if (viewModel.currentLevelIdx >= LEVELS.size) return
    val textMeasurer = rememberTextMeasurer()
    val level = LEVELS[viewModel.currentLevelIdx]
    val grid = viewModel.grid
    val h = grid.size
    if (h == 0) return
    val w = grid[0].size

    Box(
        modifier = Modifier
            .aspectRatio(1f)
            .widthIn(max = 380.dp)
            .shadow(24.dp, RoundedCornerShape(24.dp))
            .background(Color(0xFF16213E), shape = RoundedCornerShape(24.dp))
            .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(24.dp))
            .padding(12.dp)
            .pointerInput(Unit) {
                var dragOffset = Offset.Zero
                detectDragGestures(
                    onDragStart = { dragOffset = Offset.Zero },
                    onDragEnd = {
                        if (abs(dragOffset.x) > abs(dragOffset.y)) {
                            if (abs(dragOffset.x) > 40f) {
                                viewModel.move(if (dragOffset.x > 0) 1 else -1, 0)
                            }
                        } else {
                            if (abs(dragOffset.y) > 40f) {
                                viewModel.move(0, if (dragOffset.y > 0) 1 else -1)
                            }
                        }
                    }
                ) { change, dragAmount ->
                    dragOffset += dragAmount
                    change.consume()
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cellW = size.width / w
            val cellH = size.height / h
            val cellSize = min(cellW, cellH)
            val ox = (size.width - w * cellSize) / 2
            val oy = (size.height - h * cellSize) / 2

            for (y in 0 until h) {
                for (x in 0 until w) {
                    val cx = ox + x * cellSize
                    val cy = oy + y * cellSize
                    
                    drawRect(
                        Color.White.copy(alpha = 0.2f),
                        topLeft = Offset(cx, cy),
                        size = Size(cellSize, cellSize),
                        style = Stroke(width = 1f)
                    )

                    val cell = grid[y][x]
                    val pad = 2.dp.toPx()
                    if (cell == 3) {
                        drawRoundRect(
                            color = Color(0xFF0D0D0D),
                            topLeft = Offset(cx + pad, cy + pad),
                            size = Size(cellSize - pad * 2, cellSize - pad * 2),
                            cornerRadius = CornerRadius(8.dp.toPx())
                        )
                        drawRoundRect(
                            color = Color.Black.copy(alpha = 0.4f),
                            topLeft = Offset(cx + pad, cy + cellSize - pad - 4.dp.toPx()),
                            size = Size(cellSize - pad * 2, 4.dp.toPx()),
                            cornerRadius = CornerRadius(8.dp.toPx())
                        )
                    }
                }
            }

            for (t in level.targets) {
                val cx = ox + t.x * cellSize
                val cy = oy + t.y * cellSize
                
                val layoutResult = textMeasurer.measure(
                    "🍓",
                    style = TextStyle(fontSize = (cellSize * 0.6f).toSp())
                )
                drawText(
                    textLayoutResult = layoutResult,
                    topLeft = Offset(
                        cx + cellSize / 2f - layoutResult.size.width / 2f,
                        cy + cellSize / 2f - layoutResult.size.height / 2f
                    )
                )
            }

            val allJellies = mutableListOf<Point>()
            for (y in 0 until h) {
                for (x in 0 until w) {
                    if (grid[y][x] == 1 || grid[y][x] == 2) {
                        allJellies.add(Point(x, y))
                    }
                }
            }

            if (allJellies.isNotEmpty()) {
                for (i in 0 until allJellies.size) {
                    for (k in i + 1 until allJellies.size) {
                        val a = allJellies[i]
                        val b = allJellies[k]
                        if (abs(a.x - b.x) + abs(a.y - b.y) == 1) {
                            val ax = ox + a.x * cellSize + cellSize / 2
                            val ay = oy + a.y * cellSize + cellSize / 2
                            val bx = ox + b.x * cellSize + cellSize / 2
                            val by = oy + b.y * cellSize + cellSize / 2
                            
                            drawLine(
                                color = Color(0xFFFF8A80).copy(alpha = 0.75f),
                                start = Offset(ax, ay),
                                end = Offset(bx, by),
                                strokeWidth = cellSize - 4.dp.toPx(),
                                cap = StrokeCap.Round
                            )
                        }
                    }
                }

                for (j in allJellies) {
                    val cx = ox + j.x * cellSize
                    val cy = oy + j.y * cellSize
                    val pad = 2.dp.toPx()
                    val s = cellSize - pad * 2

                    val isMain = grid[j.y][j.x] == 1
                    val baseColor = if (isMain) Color(0xFFFF8A80).copy(alpha = 0.75f) else Color(0xFFFFAB91).copy(alpha = 0.75f)
                    val shadowColor = if (isMain) Color(0xFFC62828).copy(alpha = 0.75f) else Color(0xFFE57373).copy(alpha = 0.75f)

                    // Outer shadow approximation
                    drawRoundRect(
                        color = Color(0xFFFF6464).copy(alpha = 0.4f),
                        topLeft = Offset(cx + pad - 2.dp.toPx(), cy + pad + 2.dp.toPx()),
                        size = Size(s + 4.dp.toPx(), s + 4.dp.toPx()),
                        cornerRadius = CornerRadius(14.dp.toPx())
                    )

                    drawRoundRect(
                        color = shadowColor,
                        topLeft = Offset(cx + pad, cy + pad + 4.dp.toPx()),
                        size = Size(s, s),
                        cornerRadius = CornerRadius(12.dp.toPx())
                    )

                    drawRoundRect(
                        color = baseColor,
                        topLeft = Offset(cx + pad, cy + pad),
                        size = Size(s, s),
                        cornerRadius = CornerRadius(12.dp.toPx())
                    )

                    // Inner shadow / shine approximation
                    drawRoundRect(
                        color = Color.White.copy(alpha = 0.3f),
                        topLeft = Offset(cx + pad + 2.dp.toPx(), cy + pad + 2.dp.toPx()),
                        size = Size(s - 4.dp.toPx(), s / 3),
                        cornerRadius = CornerRadius(10.dp.toPx())
                    )

                    if (isMain) {
                        val ex = cx + cellSize / 2
                        val ey = cy + cellSize / 2 - 4.dp.toPx()
                        val eyeW = 4.dp.toPx()

                        drawCircle(Color.White, radius = eyeW, center = Offset(ex - 6.dp.toPx(), ey))
                        drawCircle(Color.White, radius = eyeW, center = Offset(ex + 6.dp.toPx(), ey))

                        drawLine(
                            color = Color(0xFFC62828),
                            start = Offset(ex - 4.dp.toPx(), ey + 8.dp.toPx()),
                            end = Offset(ex + 4.dp.toPx(), ey + 8.dp.toPx()),
                            strokeWidth = 2.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun WinOverlay(levelName: String, moves: Int, stars: Int, onNext: () -> Unit, onMenu: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.7f)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .background(Color(0xFF16213E), shape = RoundedCornerShape(24.dp))
                .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(24.dp))
                .padding(32.dp)
        ) {
            Text("🎉", fontSize = 64.sp)
            Spacer(modifier = Modifier.height(16.dp))
            Text("ممتاز!", fontSize = 32.sp, color = Color(0xFF81C784), fontWeight = FontWeight.Bold)
            if (stars > 0) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "★".repeat(stars) + "☆".repeat(3 - stars),
                    color = Color(0xFFFFD700),
                    fontSize = 32.sp
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text("حليت $levelName بـ $moves خطوة!", color = Color.White, fontSize = 16.sp)
            Spacer(modifier = Modifier.height(32.dp))
            Button(
                onClick = onNext,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF8A80)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth(0.8f)
            ) {
                Text("التالية", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = onMenu,
                colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.1f)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth(0.8f)
            ) {
                Text("القائمة", color = Color.White, fontSize = 18.sp)
            }
        }
    }
}

