This directory is for your image assets. Please upload the PNG files here.
